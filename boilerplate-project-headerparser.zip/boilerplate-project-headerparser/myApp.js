//Request Header Parser Microservice
require("dotenv").config();
//const bodyParser = require("body-parser");
let express = require("express");
let app = express();
let bodyParser=require("body-parser");

//get query parameter from client
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.post("/name", function(req, res) {
  // Handle the data in the request
  var string = req.body.first + " " + req.body.last;
  res.json({ name: string });
});
app.get("/name", function (req, res, next) {
  const firstname = req.query.first;
  const lastname = req.query.last;
  res.json({ name: `${firstname} ${lastname}` });
});
console.log("Hello World");
app.get("/:word/echo", function (req, res) {
  res.send(res.json({ echo: req.params.word }));
});
app.get(
  "/now",
  function (req, res, next) {
    req.time = new Date().toString();
    next();
  },
  function (req, res) {
    res.send(res.json({ time: req.time }));
  },
);
app.use(function (req, res, next) {
  console.log(req.method + " " + req.path + " - " + req.ip);
  next();
});
app.get("/", function (req, res) {
  res.sendFile(__dirname + "/views/index.html");
});

module.exports = app;
app.use("/public", express.static(__dirname + "/public"));
app.get("/json", function (req, res) {
  var response = "Hello json";
  if (process.env.MESSAGE_STYLE === "uppercase") {
    res.send(res.json({ message: response.toUpperCase() }));
  } else {
    res.send(res.json({ message: response }));
  }
});
